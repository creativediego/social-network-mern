import { IFollow } from '../models/IFollow';
import {
  noContentResponse,
  notFoundResponse,
  okResponse,
} from '../../../common/util/httpResponses';
import { IHttpRequest } from '../../../common/interfaces/IHttpRequest';
import { IHttpResponse } from '../../../common/interfaces/IHttpResponse';
import IFollowController from './IFollowController';
import { IFollowService } from '../services/IFollowService';
import { ILogger } from '../../../common/logger/ILogger';
import { ControllerError } from '../../../common/errors/ControllerError';

/**
 *  Controller that implements the path, routes, and methods for managing the  for the follows resource. Implements {@link IFollowController}. Takes {@link IFollow} DAO as dependency.
 */
export default class FollowController implements IFollowController {
  private readonly followService: IFollowService;
  private readonly logger: ILogger;
  /**
   * Constructs the controller with a follow DAO, and defines the endpoint path and routes.
   * @param {IFollowDao} followDao an implementation of a follow DAO
   */
  public constructor(followService: IFollowService, logger: ILogger) {
    this.followService = followService;
    this.logger = logger;
  }
  acceptFollow(req: IHttpRequest): Promise<IHttpResponse<IFollow>> {
    throw new Error('Method not implemented.');
  }
  /**
   * Calls the follow dao in state to create a new follow using the follower and followee id.
   * @param {IHttpRequest} req the request object containing client data
   * @returns {IHttpResponse} a response object with the new follow
   */
  public createFollow = async (
    req: IHttpRequest
  ): Promise<IHttpResponse<IFollow>> => {
    const followerId = req.params.followerId;
    const followeeId = req.params.followeeId;
    const newFollow: IFollow = await this.followService.createFollow(
      followerId,
      followeeId
    );
    this.logger.info(`User ${req.user.username} followed user ${followeeId}.`);
    return okResponse(newFollow);
  };

  /**
   * Calls the follow dao in state to delete a follow using the the user and follow object id.
   * @param {IHttpRequest} req the request object containing client data
   * @returns {IHttpResponse} a response object with the deleted follow
   */
  public deleteFollow = async (
    req: IHttpRequest
  ): Promise<IHttpResponse<void>> => {
    const followerId = req.params.followerId;
    const followeeId = req.params.followeeId;
    const deletedFollow: IFollow | null = await this.followService.deleteFollow(
      followerId,
      followeeId
    );
    if (!deletedFollow) {
      return notFoundResponse(
        new ControllerError(
          `Follow does not exist for follower:${followerId} and followee:${followeeId}.`,
          404
        )
      );
    }
    this.logger.info(
      `User ${req.user.username} unfollowed user ${followeeId}.`
    );
    return noContentResponse();
  };

  public findFollow = async (
    req: IHttpRequest
  ): Promise<IHttpResponse<IFollow>> => {
    const followerId: string = req.params.followerId;
    const followeeId: string = req.params.followeeId;

    const follow: IFollow | null = await this.followService.findFollow(
      followerId,
      followeeId
    );
    if (!follow) {
      throw new ControllerError(
        `Failed to find follow between users ${followerId} ${followeeId}.`,
        404
      );
    }
    this.logger.info(
      `User ${req.user.username} found follow between users ${followerId} and ${followeeId}.`
    );

    return okResponse(follow);
  };
}
