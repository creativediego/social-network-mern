import { Router } from 'express';
import { IDependencyContainer } from '../../../common/interfaces/IDependencyContainer';
import { Dep } from '../../../config/Dependencies';
import { adaptRequest } from '../../../common/middleware/adaptRequest';
import { isAuthenticated } from '../../../common/auth/util/isAuthenticated';
import IFollowController from '../controllers/IFollowController';

export function configFollowRoutes(
  dependencyContainer: IDependencyContainer
): Router {
  const followController = dependencyContainer.resolve<IFollowController>(
    Dep.FollowController
  );
  const router: Router = Router();

  router.post(
    '/:followerId/following/:followeeId',
    isAuthenticated,
    adaptRequest(followController.createFollow)
  );

  router.delete(
    '/:followerId/following/:followeeId',
    isAuthenticated,
    adaptRequest(followController.deleteFollow)
  );

  router.get(
    '/:followerId/following/:followeeId',
    isAuthenticated,
    adaptRequest(followController.findFollow)
  );

  return router;
}
