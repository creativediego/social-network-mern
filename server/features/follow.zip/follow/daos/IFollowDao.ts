import { IFollow } from '../models/IFollow';

export interface IFollowDao {
  createFollow(follower: string, followee: string): Promise<IFollow>;
  deleteFollow(follower: string, followee: string): Promise<IFollow | null>;
  updateFollow(
    followerId: string,
    followeeId: string,
    follow: Partial<IFollow>
  ): Promise<IFollow | null>;
  findFollow(followerId: string, followeeId: string): Promise<IFollow | null>;
}
