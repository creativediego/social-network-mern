import { Socket } from 'socket.io';
import { ServiceError } from '../../../common/errors/ServiceError';
import { ISocketService } from '../../socket/services/ISocketService';
import { IUserDao } from '../../user/daos/IUserDao';
import { IFollowDao } from '../daos/IFollowDao';
import { IFollow } from '../models/IFollow';
import { IFollowService } from './IFollowService';
import { SocketEvents } from '../../../common/enums/SocketEvents';

export class FollowService implements IFollowService {
  private readonly userDao: IUserDao;
  private readonly followDao: IFollowDao;
  private readonly socketService: ISocketService;

  public constructor(
    userDao: IUserDao,
    followDao: IFollowDao,
    socketService: ISocketService
  ) {
    this.followDao = followDao;
    this.socketService = socketService;
    this.userDao = userDao;
    Object.freeze(this);
  }

  public acceptFollow = async (
    followerId: string,
    followeeId: string
  ): Promise<IFollow | null> => {
    const acceptedFollow: IFollow | null = await this.followDao.updateFollow(
      followerId,
      followeeId,
      { accepted: true }
    );

    if (!acceptedFollow) {
      return null;
    }

    this.socketService.emitToRoom(
      followeeId,
      SocketEvents.UPDATED_FOLLOW,
      acceptedFollow
    );
    return acceptedFollow;
  };

  public findFollow = async (
    followerId: string,
    followeeId: string
  ): Promise<IFollow | null> =>
    await this.followDao.findFollow(followerId, followeeId);

  public createFollow = async (
    followerId: string,
    followeeId: string
  ): Promise<IFollow> => {
    // Check if follow exists already
    const existingFollow = await this.followDao.findFollow(
      followerId,
      followeeId
    );
    if (existingFollow) {
      return existingFollow;
    }
    // Check if follower and followee exist
    const follower = await this.userDao.findById(followerId);
    const followee = await this.userDao.findById(followeeId);
    if (!follower || !followee) {
      throw new ServiceError('Cannot create follow. User does not exist.');
    }

    // Create new follow
    const newFollow: IFollow = await this.followDao.createFollow(
      followerId,
      followeeId
    );

    // Emit a new update to the Socket server when a new follow notification is created
    this.socketService.emitToRoom(
      followeeId,
      SocketEvents.NEW_FOLLOW,
      newFollow
    );

    return newFollow;
  };

  public deleteFollow = async (
    followerId: string,
    followeeId: string
  ): Promise<IFollow | null> => {
    const deletedFollow = await this.followDao.deleteFollow(
      followerId,
      followeeId
    );

    if (!deletedFollow) {
      return null;
    }

    // Emit a new update to the Socket server when a new follow notification is created
    this.socketService.emitToRoom(
      followeeId,
      SocketEvents.DELETED_FOLLOW,
      deletedFollow
    );
    return deletedFollow;
  };
}
