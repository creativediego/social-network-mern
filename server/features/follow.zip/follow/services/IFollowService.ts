import { IFollow } from '../models/IFollow';

export interface IFollowService {
  createFollow: (followerId: string, followeeId: string) => Promise<IFollow>;
  findFollow: (
    followerId: string,
    followeeId: string
  ) => Promise<IFollow | null>;
  acceptFollow: (
    followerId: string,
    followeeId: string
  ) => Promise<IFollow | null>;
  deleteFollow: (
    followerId: string,
    followeeId: string
  ) => Promise<IFollow | null>;
}
